const express = require('express');
const fs = require('node:fs');
const path = require('node:path');
require('dotenv').config({ path: path.join(__dirname, '../.env'), quiet: true });
require('dotenv').config({ path: path.join(__dirname, '.env'), quiet: true });
const igdb = require('./igdb.cjs').createIGDB();
const { DatabaseSync } = require('node:sqlite');
const catalogue = require('./library.cjs').createLibrary();
const app = express();
const directory = process.env.GAMESHUB_DATA_DIR || path.join(__dirname, 'data');
fs.mkdirSync(directory, { recursive: true });
const db = new DatabaseSync(path.join(directory, 'gameshub.sqlite'));
db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
  CREATE TABLE IF NOT EXISTS discussions(
    id INTEGER PRIMARY KEY, game_id TEXT NOT NULL,
    mode TEXT NOT NULL CHECK(mode IN ('spoiler-free','deep-dive')),
    parent_id INTEGER REFERENCES discussions(id), author TEXT NOT NULL,
    body TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE INDEX IF NOT EXISTS discussion_scope ON discussions(game_id,mode,parent_id,id);`);
app.disable('x-powered-by');
app.use(express.json({ limit: '12kb' }));
app.use((req, res, next) => {
  res.set({ 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin' });
  if (req.path.startsWith('/api/')) res.set('Cache-Control', 'no-store');
  next();
});
const modes = new Set(['spoiler-free', 'deep-dive']);
const buckets = new Map();
function game(req, res, next) {
  req.game = catalogue.find(item => item.id === req.params.id);
  if (!req.game) return res.status(404).json({ error: 'Game not found.' });
  next();
}
function mode(req, res, next) {
  req.mode = req.query.mode || 'spoiler-free';
  if (!modes.has(req.mode)) return res.status(400).json({ error: 'Choose spoiler-free or deep-dive mode.' });
  next();
}
const summary = item => ({ id: item.id, title: item.title, year: item.year, developer: item.developer,
  genre: item.genre, franchise: item.franchise, subseries: item.subseries || '', platforms: item.platforms,
  status: item.status, hasDossier: item.hasDossier, aliases: item.aliases || [],
  tagline: item.tagline, image: /^https:\/\//i.test(item.image) ? item.image : `/gameshub/images/${item.image}`, accent: item.accent,
  characters: item.characters.length, chapters: item.story.length });
app.get('/api/health', (req, res) => res.json({ status: 'ok' }));
app.get('/api/games', (req, res) => res.json({ games: catalogue.map(summary), igdb: { configured: igdb.configured } }));
const upstream = handler => async (req, res) => {
  try { await handler(req, res); }
  catch (error) { res.status([400,429,503].includes(error.status) ? error.status : 502).json({ error: error.status ? error.message : 'IGDB is temporarily unavailable.' }); }
};
app.get('/api/igdb/status', (req, res) => res.json({ configured: igdb.configured }));
app.get('/api/igdb/search', upstream(async (req, res) => res.json({ games: await igdb.search(req.query.q) })));
app.get('/api/igdb/library', upstream(async (req, res) => {
  const ids = typeof req.query.ids === 'string' ? [...new Set(req.query.ids.split(','))] : [];
  if (!ids.length || ids.length > 18 || ids.some(id => !catalogue.some(g => g.id === id))) return res.status(400).json({ error: 'Choose 1 to 18 library game IDs.' });
  res.json({ matches: await igdb.match(ids.map(id => catalogue.find(g => g.id === id))) });
}));
app.get('/api/games/:id/igdb', game, mode, upstream(async (req, res) => res.json({ game: await igdb.detail(req.game, req.mode === 'deep-dive') })));
app.get('/api/games/:id', game, mode, (req, res) => {
  const item = req.game;
  const deep = req.mode === 'deep-dive';
  res.json({ ...summary(item), mode: req.mode, release: item.release, tone: item.tone,
    setting: item.setting, history: item.history, timeline: item.timeline,
    characters: item.characters.map(character => ({ name: character.name, role: character.role,
      bio: deep ? `${character.safe} ${character.deep}` : character.safe })),
    ...(deep ? { story: item.story } : {}),
    sources: item.sources.filter(source => deep || source[2] === 'safe').map(([label, url]) => ({ label, url })),
  });
});
app.get('/api/games/:id/discussions', game, mode, (req, res) => {
  const threads = db.prepare('SELECT * FROM discussions WHERE game_id=? AND mode=? AND parent_id IS NULL ORDER BY id DESC LIMIT 30').all(req.game.id, req.mode);
  const replies = db.prepare('SELECT * FROM discussions WHERE parent_id=? AND game_id=? AND mode=? ORDER BY id LIMIT 50');
  res.json({ mode: req.mode, threads: threads.map(thread => ({ ...thread, replies: replies.all(thread.id, req.game.id, req.mode) })) });
});
app.post('/api/games/:id/discussions', game, (req, res) => {
  const trusted = new Set([process.env.PUBLIC_ORIGIN || `http://${req.headers.host}`,
    ...(process.env.NODE_ENV === 'production' ? [] : JSON.parse(process.env.PORTFOLIO_LOCAL_ORIGINS || '[]'))]);
  if (!trusted.has(req.headers.origin)) return res.status(403).json({ error: 'Open Gameshub on this server to post.' });
  if (!req.is('application/json')) return res.status(415).json({ error: 'Use JSON to post a discussion.' });
  const { author, body, mode: readingMode, parentId = null } = req.body || {};
  if (!modes.has(readingMode) || typeof author !== 'string' || typeof body !== 'string' || author.trim().length < 2 || author.trim().length > 40 || body.trim().length < 3 || body.trim().length > 2000) {
    return res.status(400).json({ error: 'Use a name of 2–40 characters and a message of 3–2,000 characters.' });
  }
  if (parentId !== null && (!Number.isSafeInteger(parentId) || !db.prepare('SELECT id FROM discussions WHERE id=? AND game_id=? AND mode=? AND parent_id IS NULL').get(parentId, req.game.id, readingMode))) {
    return res.status(400).json({ error: 'That discussion does not belong to this game and reading mode.' });
  }
  const now = Date.now();
  for (const [key, value] of buckets) if (value.until <= now) buckets.delete(key);
  const key = req.socket.remoteAddress || 'local';
  const bucket = buckets.get(key) || { count: 0, until: now + 60000 };
  if (bucket.count >= 10 || (!buckets.has(key) && buckets.size >= 10000)) return res.status(429).json({ error: 'A few too many posts. Please try again in a minute.' });
  bucket.count += 1; buckets.set(key, bucket);
  const result = db.prepare('INSERT INTO discussions(game_id,mode,parent_id,author,body) VALUES(?,?,?,?,?)').run(req.game.id, readingMode, parentId, author.trim(), body.trim());
  res.status(201).json({ id: Number(result.lastInsertRowid) });
});
app.use('/api', (req, res) => res.status(404).json({ error: 'API route not found.' }));
app.use(express.static(path.join(__dirname, 'public'), { index: 'index.html', dotfiles: 'deny' }));
app.use((error, req, res, next) => {
  if (res.headersSent) return next(error);
  res.status(error.status === 413 ? 413 : error instanceof SyntaxError ? 400 : 500).json({ error: error.status === 413 ? 'Message too large.' : error instanceof SyntaxError ? 'Invalid JSON.' : 'Gameshub could not complete the request.' });
});
if (require.main === module) app.listen(process.env.PORT || 3004, '0.0.0.0', () => console.log(`Gameshub: http://localhost:${process.env.PORT || 3004}`));
module.exports = { app, db };
